from fastapi import APIRouter
from .views import index

ROOT = APIRouter(
	tags=["MAIN"]
)

ROOT.include_router(index.ROUTER)