import sys
import time

def display(string):
	for char in string:
		sys.stdout.write(char)
		sys.stdout.flush()
		time.sleep(0.05) 

def filter_sentences(sentences, word):
	filtered = []
	for sentence in sentences:
		if word in sentence:
			continue
		filtered.append(sentence)
	return filtered

def calculate_params(model):
	params = sum(p.numel() for p in model.parameters() if p.requires_grad)
	buffer = sum(p.numel() for p in model.buffers())
	total_params = params + buffer
	
	output = f"Jumlah parameter dari model {model.__class__.__name__}: \nParameters: {params:,}\nBuffer: {buffer:,}"
	return output

def extract_entity_value(sentence, patterns, entity_type):
	for pattern in patterns:
		if pattern.find('{' + entity_type + '}') != -1:
			pattern_words = pattern.split()
			sentence_words = sentence.split()
			for pattern_word, sentence_word in zip(pattern_words, sentence_words):
				if pattern_word == '{' + entity_type + '}':
					return sentence_word
	return None

def apply_entities_to_response(response, entities):
	for entity_type, entity_value in entities.items():
		response = response.replace('{' + entity_type + '}', entity_value)
	return response