import torch
import random
import json

from model import NeuralNet
from nltk_utils import bag_of_words, tokenize
from utils import filter_sentences, extract_entity_value, apply_entities_to_response

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

FILE = "data.pth"
data = torch.load(FILE)

input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
all_words = data['all_words']
tags = data['tags']
model_state = data["model_state"]
intents = data["intents"]

model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)
model.eval()

class Arisu:
	def process_response(sentence, tag):
		entities = {}
		patterns = None
		x = "{none}"
		for intent in intents['intents']:
			if intent['tag'] == tag:
				patterns = intent['patterns']
				for context in intent.get('context', []):
					x = "{" + context + "}"
					entity_value = extract_entity_value(sentence, patterns, context)
					if entity_value:
						entities[context] = entity_value	
			break
		if entities:
			for intent in intents['intents']:
				if intent['tag'] == tag:
					response = apply_entities_to_response(random.choice(intent["responses"]), entities)
					return response
		else:
			for intent in intents['intents']:
				if intent['tag'] == tag:
					response = random.choice(filter_sentences(intent["responses"], x))
					return response
		return None

	def generate(text):
		sentence = tokenize(text)
		X = bag_of_words(sentence, all_words)
		X = X.reshape(1, X.shape[0])
		X = torch.from_numpy(X).to(device)

		output = model(X)
		_, predicted = torch.max(output, dim=1)

		tag = tags[predicted.item()]

		probs = torch.softmax(output, dim=1)
		prob = probs[0][predicted.item()]

		if prob.item() > 0.85:
			for intent in intents['intents']:
				if tag == intent["tag"]:
					response = process_response(text, tag)
					return response, {"probabilities": prob, "tag": tag}
					break
		else:
			return "Arisu tidak mengerti apa yang kamu katakan TwT\n", {"probabilities": prob, "tag": tag}