from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates, JSONResponse

import csv
import json
import requests
from datetime import datetime
from typing import List

ROUTER = APIRouter()

TEMPLATES = Jinja2Templates(directory="public")


@ROUTER.get("/", response_class=HTMLResponse, summary="Home page", status_code=200)
async def root(request: Request):
	"""
	Return the main page of this web
	"""
	return TEMPLATES.TemplateResponse("main/index.html", {"request": request})


@ROUTER.get(
	"/about", response_class=HTMLResponse, summary="About page", status_code=200
)
async def about(request: Request):
	"""
	About me
	"""
	return TEMPLATES.TemplateResponse("main/about.html", {"request": request})


@ROUTER.get("/chat")
async def index():
	return HTMLResponse("""
		<html>
			<head>
				<title>Chat with Model</title>
				<script>
					function displayMessage(message) {
						const conversation = document.getElementById("conversation");
						const typingIndicator = document.getElementById("typing-indicator");
						const li = document.createElement("li");
						li.innerText = message;
						conversation.appendChild(li);
						typingIndicator.style.display = "none";
					}

					async function sendMessage() {
						const input = document.getElementById("message-input");
						const message = input.value.trim();
						input.value = "";
						if (message) {
							const conversation = document.getElementById("conversation");
							const typingIndicator = document.getElementById("typing-indicator");
							const li = document.createElement("li");
							li.classList.add("user-message");
							li.innerText = message;
							conversation.appendChild(li);
							typingIndicator.style.display = "block";
							const response = await fetch(`/get_message?message=${message}`);
							const data = await response.json();
							displayMessage(data.message);
						}
					}
				</script>
				<style>
					#typing-indicator {
						display: none;
						animation: blink .7s infinite alternate;
					}

					@keyframes blink {
						from {
							opacity: 1;
						}
						to {
							opacity: 0;
						}
					}

					.user-message {
						text-align: right;
					}
				</style>
			</head>
			<body>
				<h1>Chat with Model</h1>
				<ul id="conversation"></ul>
				<form onsubmit="sendMessage(); return false;">
					<input id="message-input" type="text" autofocus>
					<button type="submit">Send</button>
				</form>
				<p id="typing-indicator">Typing...</p>
			</body>
		</html>
	""")


@ROUTER.get("/get_message")
async def send_message(message: str):
	response = requests.get(f"/generate?string={message}")
	log = {
		"timestamp": datetime.now().isoformat(),
		"user_message": message,
		"model_response": response.json()["generated_text"]
	}
	with open("log.csv", "a", newline='') as f:
		writer = csv.writer(f)
		if f.tell() == 0:
			writer.writerow(log.keys())
		writer.writerow(log.values())
	return JSONResponse(content={"message": log["model_response"]})


@ROUTER.get("/generate")
async def generate(string: str):
	from core.model.Arisu.main import Arisu
	text, _ = Arisu.generate(string)
	return JSONResponse(content={"generated_text": text})


@ROUTER.get("/download_csv")
async def download_csv(response: Response, key: str):
	if key == "hitori-chan":
    	response.headers["Content-Disposition"] = "attachment; filename=log.csv"
    	with open("log.csv", "r") as f:
			contents = f.read()
    	return Response(content=contents, media_type="text/csv")
	else:
		return JSONResponse(content={"details": "invalid keys!"})